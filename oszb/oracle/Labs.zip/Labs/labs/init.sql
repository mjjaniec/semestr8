alter session set NLS_LANGUAGE='ENGLISH';
set linesize 126;
set pagesize 36;
set serveroutput on;