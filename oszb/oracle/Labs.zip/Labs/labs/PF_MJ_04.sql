create flashback archive default default_flashback_archive 
		tablespace example quota 10M retention 1 year;
alter table hr.departments_mj flashback archive;
-- alter table hr.departments_mj no flashback archive;
alter table hr.departments_mj enable row movement;


insert into hr.departments_mj values(trunc(dbms_random.value(1000,2000)), 'mj_1', null, 1700);
commit;
insert into hr.departments_mj values(trunc(dbms_random.value(1000,2000)), 'mj_2', null, 1700);
commit;
insert into hr.departments_mj values(trunc(dbms_random.value(1000,2000)), 'mj_3', null, 1700);
commit;