create or replace procedure refresh_indexes is
begin
	for index_record in (select owner, index_name from dba_indexes where owner = 'HR' and table_name = 'EMPLOYEES'  and status = 'UNUSABLE')
	loop
		execute immediate 'ALTER INDEX '||index_record.owner||'.'||index_record.index_name||' REBUILD';
	end loop; 
end;
/



begin
    dbms_scheduler.create_job(job_name        => 'refresh_indexes_job',
                              job_type        => 'STORED_PROCEDURE',
                              job_action      => 'refresh_indexes',
                              start_date      => systimestamp,
                              end_date        => null,
                              repeat_interval => 'freq=daily; byhour=10; byminute=0; bysecond=0;',
                              enabled         => true,
                              auto_drop       => false,
                              comments        => 'your description here.');
end;
/