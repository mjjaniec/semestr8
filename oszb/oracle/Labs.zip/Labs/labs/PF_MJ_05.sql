

declare 
	i number;
begin
	i := 0;
	for scn in (select commit_scn from flashback_transaction_query
			where table_owner = 'HR' and table_name = 'DEPARTMENTS_MJ'
			order by commit_scn desc) loop
		i := i + 1;
		if i = 3 then 
			execute immediate 'flashback table hr.departments_mj to scn '||to_char(scn.commit_scn);
			exit;
		end if;
	end loop;
end;
/