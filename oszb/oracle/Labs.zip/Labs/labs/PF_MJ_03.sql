FLASHBACK TABLE hr.departments_mj TO BEFORE DROP;

declare
	val number;
begin
	-- very ugly but do the work
	val := 0;
	for unused in (select * from hr.departments_mj) loop
		val := val + 1;
	end loop;
	dbms_output.put_line(val);
end;
/