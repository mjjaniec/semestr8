create or replace PROCEDURE time_counter is
        emp hr.employees%rowtype;
        timestart NUMBER;
begin
        timestart:=dbms_utility.get_time();
        for i in 1..25000 loop
                select * into emp from hr.employees where salary > 9500 and manager_id = 146;
        end loop;
        dbms_output.put_line(dbms_utility.get_time()-timestart||' x 0.01s');
end;
/