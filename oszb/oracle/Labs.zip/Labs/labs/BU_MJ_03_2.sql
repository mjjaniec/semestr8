alter system set log_archive_dest_1 = 'LOCATION=USE_DB_RECOVERY_FILE_DEST';
alter system set log_archive_dest_2 = 'LOCATION=E:\\storage\\archive_2_mj';
alter system set log_archive_dest_state_1 = enable;
alter system set log_archive_dest_state_2 = enable;
alter system set log_archive_min_succeed_dest = 1;