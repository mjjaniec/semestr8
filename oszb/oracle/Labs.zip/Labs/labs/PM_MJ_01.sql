-- hr.employees table would be moved back and forth using temporary table space to de-fragment it.

ALTER TABLE hr.employees MOVE TABLESPACE inventory;
ALTER TABLE hr.employees MOVE TABLESPACE example;