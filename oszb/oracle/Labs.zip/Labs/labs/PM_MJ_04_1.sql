create table sh.sales_mj_copy as select * from sh.sales;
begin
	for i in 1..100 loop
		for entry in (select  prod_id, cust_id, time_id, channel_id, promo_id, quantity_sold, amount_sold 
				from sh.sales_mj_copy) 
		loop
			delete from sh.sales_mj_copy where
					prod_id = entry.prod_id and
					cust_id = entry.cust_id and
					time_id = entry.time_id and
					promo_id = entry.promo_id and
					quantity_sold = entry.quantity_sold and
					amount_sold = entry.amount_sold;
		end loop;
		insert into sh.sales_mj_copy select * from sh.sales;
	end loop;
end;
/