select * from hr.departments_mj;
@PF_MJ_05.sql;
select * from hr.departments_mj;